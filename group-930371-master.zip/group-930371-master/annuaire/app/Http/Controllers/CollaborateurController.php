<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Collaborateur;
use App\Models\Entreprise;


class CollaborateurController extends Controller
{   
    public function __construct()
     {
          $this->authorizeResource(Collaborateur::class, 'collaborateur');
     }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $collaborateurs = Collaborateur::all();

        return view('collaborateurs.index', [
            'collaborateurs' => $collaborateurs
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()

    {   
        $ids = Entreprise::pluck('id', 'nom');
        return view('collaborateurs.create', ['ids'=>$ids]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nom' => 'required|max:255',
            'genre' => 'required',
            'prenom' => 'required',
            'rue' => 'required',
            'code_postal' => 'required|max:5',
            'ville' => 'required',
            'numero_de_telephone' => 'unique:collaborateurs',//il faut voir pour le format du tel,
            'email' => 'required|unique:collaborateurs',
            'nom_entreprise' => 'required'   
        ]);

        /*$validated['entreprise_id'] = 1;
        Collaborateur::create($validated);*/
        //dd($validated);
        $collaborateur = new Collaborateur;

        $collaborateur->civilite = $validated['genre'];
        $collaborateur->nom = $validated['nom'];
        $collaborateur->prenom = $validated['prenom'];
        $collaborateur->rue = $validated['rue'];
        $collaborateur->code_postal = $validated['code_postal'];
        $collaborateur->ville = $validated['ville'];
        $collaborateur->numero_de_telephone = $validated['numero_de_telephone'];
        $collaborateur->email = $validated['email'];
        $collaborateur->entreprise_id = $validated['nom_entreprise'];


        $collaborateur->save();
        
        return redirect()->route('collaborateur.index', ['collaborateurs' => $collaborateur->id]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Collaborateur $collaborateur)
    {   
        $ids = Entreprise::pluck('id', 'nom');
        return view('collaborateurs.edit', ['ids'=>$ids, 'collaborateur'=> $collaborateur]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Collaborateur $collaborateur)
    {
    
        $validated = $request->validate([
            'nom' => 'required|max:255',
            'genre' => 'required',
            'prenom' => 'required',
            'rue' => 'required',
            'code_postal' => 'required|max:5',
            'ville' => 'required',
            'numero_de_telephone' => 'required',//il faut voir pour le format du tel,
            'email' => 'required',
            'nom_entreprise' => 'required'  
        ]);

        /*$validated['entreprise_id'] = 1;
        Collaborateur::create($validated);*/


        $collaborateur->civilite = $validated['genre'];
        $collaborateur->nom = $validated['nom'];
        $collaborateur->prenom = $validated['prenom'];
        $collaborateur->rue = $validated['rue'];
        $collaborateur->code_postal = $validated['code_postal'];
        $collaborateur->ville = $validated['ville'];
        $collaborateur->numero_de_telephone = $validated['numero_de_telephone'];
        $collaborateur->email = $validated['email'];
        $collaborateur->entreprise_id = $validated['nom_entreprise'];


        $collaborateur->save();
            

        return redirect()->route('collaborateur.index', ['collaborateurs' => $collaborateur->id]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Collaborateur $collaborateur)
    {
        $collaborateur->delete();
        
        return redirect()->route('collaborateur.index'); //la suppression affiche des messages d'erreurs mais supprime quand mm
    }
}
