<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Entreprise;

class EntrepriseController extends Controller
{
     public function __construct()
     {
          $this->authorizeResource(Entreprise::class, 'entreprise');
     }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        
        //$this->authorize('viewAny', Entreprise::class);
        
        $entreprises = Entreprise::all();

        return view('entreprises.index', [
            'entreprises' => $entreprises
        ]);
        
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //$this->authorize('create', Entreprise::class);

        return view('entreprises.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //$this->authorize('create', Entreprise::class);

        $validated = $request->validate([
            'nom' => 'required|unique:entreprises|max:255',
            'rue' => 'required',
            'code_postal' => 'required|max:5',
            'ville' => 'required',
            'numero_de_telephone' => 'required|unique:entreprises',//il faut voir pour le format du tel,
            'email' => 'required|unique:entreprises'
        ]);

         //dd('$validated');

        /*$validated['id'] = 1;
        Post::create($validated);*/

        $entreprise = new Entreprise;

        $entreprise->nom = $validated['nom'];
        $entreprise->rue = $validated['rue'];
        $entreprise->code_postal = $validated['code_postal'];
        $entreprise->ville = $validated['ville'];
        $entreprise->numero_de_telephone = $validated['numero_de_telephone'];
        $entreprise->email = $validated['email'];

        $entreprise->save();

        return redirect()->route('entreprise.index', ['entreprises' => $entreprise->id]);
    }



    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Entreprise $entreprise)
    {
        
        //$validated = $request->validate([
            //'search' => 'required|min:2',
        //]);

        //$search = $request['search'];
        //$entreprise = Entreprise::Where('nom', 'LIKE', '%'.$search.'%')->orWhere('ville', 'LIKE', '%' .$search. '%')->orWhere('email', 'LIKE', '%' .$search. '%')->get();
        return view('entreprises.show', [ 'entreprise' => $entreprise]);
    }
     /*@param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Entreprise $entreprise)
    {
        //$this->authorize('update', $entreprise);
        

        return view('entreprises.edit', ['entreprise' => $entreprise]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Entreprise $entreprise)

    {
        //$this->authorize('update', $entreprise);

        $validated = $request->validate([
            'nom' => 'required|max:255',
            'rue' => 'required',
            'code_postal' => 'required|max:5',
            'ville' => 'required',
            'numero_de_telephone' => 'required',//il faut voir pour le format du tel,
            'email' => 'required'
        ]);

            $entreprise->nom = $validated['nom'];
            $entreprise->rue = $validated['rue'];
            $entreprise->code_postal = $validated['code_postal'];
            $entreprise->ville = $validated['ville'];
            $entreprise->numero_de_telephone = $validated['numero_de_telephone'];
            $entreprise->email = $validated['email'];

            $entreprise->save();

            return redirect()->route('entreprise.index', ['entreprises' => $entreprise->id]);
    }


        


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Entreprise $entreprise)
    {
        //$this->authorize('delete', $entreprise);

        $entreprise->delete();
        $entreprises = Entreprise::All();

        return redirect()->route('entreprise.index');
    }
}
