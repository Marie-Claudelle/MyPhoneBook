<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Collaborateur extends Model
{
    use HasFactory;
    protected $fillable = [
        'civilité',
        'nom',
        'prenom',
        'rue',
        'code_postal',
        'ville',
        'numero_de_telephone',
        'email',
        'entreprise_id',
    ];
    public $timestamps = false;

    public function entreprise(){
        return $this->belongsTo(Entreprise::class);
    }
}
