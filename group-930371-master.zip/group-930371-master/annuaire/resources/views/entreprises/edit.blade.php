<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>My Phone Book</title>
   <link rel="stylesheet" type="text/css"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <script type="text/javascript" src="connexion.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>


<script>
  $( function() {
    $( "#tabs" ).tabs();
  } );
  </script>

</head>

<body>





    <div class="text">
        <h1 style="color: coral;padding-left: 525px; align: center;">Création d'entreprise</h1>
    </div>


    <!--tab creer modifier supprimer-->
    <div id="tabs">
       

        <div id="tabs-1">
            <!--creer une entreprise-->

            @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
                        </ul>
                    </div>
            @endif


            <form action="{{ route('entreprise.update', $entreprise->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div style="margin: auto;width: 60%; margin-left: 30%;">

                    <div style="display: inline-block; padding-right: 20%; padding-top: 10%;"><label
                            for="nom"><strong>Nom de l'entreprise*</strong></label><br />
                        <input type="text" name="nom" value="{{ $entreprise->nom }}" required="" style="height: 45px;" />
                    </div>

                    <div style="display: inline-block;"><label for="ville"><strong>Ville*</strong></label><br />
                        <input type="text" name="ville" value="{{ $entreprise->ville }}" required="" style="height: 45px;" />
                    </div>

                    <div class="let" style="display: inline-block;padding-right:20%;padding-top: 10%;"><label
                            for="rue"><strong> Rue*</strong></label><br />
                        <input type="text" name="rue" value="{{ $entreprise->rue }}" required="" style="height: 45px;" />
                    </div>

                    <div class="let" style="display: inline-block;"><label for="code_postal"><strong>Code Postal* </strong></label><br />
                        <input type="nombre" name="code_postal" value="{{ $entreprise->code_postal }}" style="height: 45px;" placeholder="1xxxx" required=""/>
                    </div>

                    <div class="let" style="display: inline-block; padding-right: 20%; padding-top: 10%;"><label for="numero_de_telephone"><strong>Numéro de téléphone*</strong></label><br />
                        <input type="tel" name="numero_de_telephone" value="{{ $entreprise->numero_de_telephone }}" placeholder="0xxxxxxxxx" pattern="01[0-9]{8}" required="" style="height: 45px;" />
                    </div>

                    <div class="let" style="display: inline-block;"><label for="email"><strong>Email* </strong> </label><br>
                    <input type="email" placeholder="votre email" required="" value="{{ $entreprise->email }}" name="email" style="height: 45px"><br>
                    </div>

                    <div><input type="submit" value="modifier" style="margin-left: 700px;" /></div>

                </div>
                    
               
            </form>

        </div>


    <!--script-->
    <script rel="stylesheet" type="text/css"
        src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </script>
    <script type="text/javascript" src="connexion.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    

</body>

</html>
