<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://127.0.0.1:8000/css/collaborateur.css" type="text/css" media="screen" />
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <title>Document</title>
</head>


<body>
    <h2>LISTE DES ENTREPRISES</h2>
   
    <div class="table-wrapper">
        {{-- <a href= "{{route('entreprise.show')}}">
            <button><i style="font-size:15px" class="fa">&#xf044;</i> recherchez une entreprise</button>
        </a> --}}
        {{-- @if(count($entreprises)>0) --}}
        <table class="fl-table">
            <thead>
                <tr>
                    <th>Nom</th>
                    {{-- <th>Rue</th> --}}
                    <th>Code postal</th>
                    {{-- <th>Ville</th> --}}
                    <th>Numéro de téléphone</th>
                    <th>Email</th>
                    <th>Action</th>


                </tr>
            </thead>
            {{-- @foreach ($entreprises as $entreprise) --}}
            <tbody>
                <tr>
                    <td>{{$entreprise -> nom }}</td>
                    {{-- <td>{{$entreprise -> rue }}</td> --}}
                    <td>{{$entreprise -> code_postal }}</td>
                    {{-- <td>{{$entreprise -> ville }}</td> --}}
                    <td>{{$entreprise -> numero_de_telephone }}</td>
                    <td>{{$entreprise -> email }}</td>
                    
                    <td id="icons">
                        
                             
                        <div>
                            <a href="{{ route('entreprise.edit', $entreprise->id) }}">
                            <button> <i style="font-size:15px" class="fa">&#xf044;</i></button>
                            </a>
                        </div>
                            
                            
                        <div>
                                {{-- <i class='fas fa-trash-alt'></i> --}}
                            <form action="{{ route('entreprise.destroy', $entreprise->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                        
                                <button type="submit"><i style="font-size:15px" class="fa fa-trash"></i></button>
                            </form>
            
                        </div>
                            

                        
                    </td>
                </tr>
                {{-- @endforeach --}}

                <tbody>
        </table>
        {{-- @else
         <h1> Aucune entreprise correspondant à votre recherche</h1>
        @endif --}}
    </div>

</body>

</html>



<style>
    * {
        box-sizing: border-box;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
    }
    
    body {
        font-family: Helvetica;
        -webkit-font-smoothing: antialiased;
        /* background: rgba( 71, 147, 227, 1); */
    }
    
    h2 {
        text-align: center;
        font-size: 18px;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: rgba(8, 6, 36, 0.863);
        padding: 30px 0;
    }
    /* Table Styles */
    
    .table-wrapper {
        margin: 10px 70px 70px;
        box-shadow: 0px 35px 50px rgba( 0, 0, 0, 0.2);
    }
    
    .fl-table {
        border-radius: 5px;
        font-size: 12px;
        font-weight: normal;
        border: none;
        border-collapse: collapse;
        width: 100%;
        max-width: 100%;
        white-space: nowrap;
        background-color: white;
    }
    
    .fl-table td,
    .fl-table th {
        text-align: center;
        padding: 8px;
    }
    #icons{
        display: flex;
        justify-content: space-between;
    }
    
    .fl-table td {
        border-right: 1px solid #f8f8f8;
        font-size: 12px;
    }
    
    .fl-table thead th {
        color: #ffffff;
        background: #4FC3A1;
    }
    
    .fl-table thead th:nth-child(odd) {
        color: #ffffff;
        background: #324960;
    }
    
    .fl-table tr:nth-child(even) {
        background: #F8F8F8;
    }
    /* Responsive */
    
    @media (max-width: 767px) {
        .fl-table {
            display: block;
            width: 100%;
        }
        .table-wrapper:before {
            content: "Scroll horizontally >";
            display: block;
            text-align: right;
            font-size: 11px;
            color: white;
            padding: 0 0 10px;
        }
        .fl-table thead,
        .fl-table tbody,
        .fl-table thead th {
            display: block;
        }
        .fl-table thead th:last-child {
            border-bottom: none;
        }
        .fl-table thead {
            float: left;
        }
        .fl-table tbody {
            width: auto;
            position: relative;
            overflow-x: auto;
        }
        .fl-table td,
        .fl-table th {
            padding: 20px .625em .625em .625em;
            height: 60px;
            vertical-align: middle;
            box-sizing: border-box;
            overflow-x: hidden;
            overflow-y: auto;
            width: 120px;
            font-size: 13px;
            text-overflow: ellipsis;
        }
        .fl-table thead th {
            text-align: left;
            border-bottom: 1px solid #f7f7f9;
        }
        .fl-table tbody tr {
            display: table-cell;
        }
        .fl-table tbody tr:nth-child(odd) {
            background: none;
        }
        .fl-table tr:nth-child(even) {
            background: transparent;
        }
        .fl-table tr td:nth-child(odd) {
            background: #F8F8F8;
            border-right: 1px solid #E6E4E4;
        }
        .fl-table tr td:nth-child(even) {
            border-right: 1px solid #E6E4E4;
        }
        .fl-table tbody td {
            display: block;
            text-align: center;
        }
    }
</style>
