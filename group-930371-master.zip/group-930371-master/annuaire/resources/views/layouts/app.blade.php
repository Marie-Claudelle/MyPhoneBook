<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                            @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }}
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
            <h1 style="text-align: center">Bienvenue dans notre annuaire !</h1>
        </nav>

        <main class="py-4">
            @yield('content')
            <section id="banner">
                <h1 id="title_banner">
                    Bienvenue dans notre annuaire !
                </h1>
                <h2 id="paragraph_banner">
                    Ceci est un annuaire électronique <br> qui représente tous les entreprises et collaborateurs.<br> Attention vous devez vous connecter pour consulter notre annuaire
                </h2>
            </section>
            <section id="features">
                <div class="card">
                    <a href= "{{route('entreprise.index')}}"><img src="https://img-0.journaldunet.com/gcFxQdXNrx_SEqEx53NYdxidcGM=/1500x/smart/df12c3d6f77445008518acae53aa34a4/ccmcms-jdn/11174895.jpg" alt="" height="100px" width="200px"></a>
                    <div class="container">
                        <h4><b>ENTREPRISES</b></h4>
                        <p>La liste de nos entreprises <br> sont mise à jour tous les jours</p>
                        {{-- <a href= "{{route('entreprise.create')}}"></a> --}}
                    </div>
                </div>
                <div class="card">
                    <a href= "{{route('collaborateur.index')}}"><img src="https://blog.wisembly.com/wp-content/uploads/2015/08/reunions-collaborateurs-acteurs-efficacite-wisembly.jpg" alt="" height="100px" width="200px"></a>
                    <div class="container">
                        <h4><b>COLLABORATEURS</b></h4>
                        <p>La liste de nos collaborateurs <br> sont mise à jour tous les jours
                    </div>
                </div>
            </section>
        </main>
        <footer>
            <div id="contact_foot">
                <div class="logo2">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1u0AppnW5p4OwZkKEvgd8qI41d8O9OzsHkg&usqp=CAU" alt="" height="50px" width="70px">
                </div>
                <div class="social_networks">
                    <div class="twitter">
                        <a href="twitter.png">
                            <img src="https://icones.pro/wp-content/uploads/2021/02/icone-twitter-bleue.png" alt="" height="20px" width="20px" />
                        </a>
                    </div>
                    <div class="facebook">
                        <a href="facebook.png">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAllBMVEU7WZkwSHz///8UNnLd4Oo1VZdqf64sT5QyS4EiPnYkQHebpr/W2+gyU5bIzdsbOnWWoLm1vtWLl7U4VZOQnsHO1OOFlbxWbqRPaaIcRpDm6fG6wthFYZ0kSpEtUJX19vrw8vZ8jLYAKmxid6lyhLGeq8map8eos82Ej6x1g6S3vtFpd5ust9HDy90+V4kJMnJLX458iqsnU8U4AAAFr0lEQVR4nO3d63aiOhgG4JQhpK1mqi2BiAbt1h7mtGf2/d/cBpXWA8Qx5Mj63n/9o3nWF5IQsEHRWeJpmvAFCi0LnqTT+JyDTv5mGRIlxa6bqxRMS4EyJhXOc0Fdt7NnqMjnnULGSZjFOw4mnLULs9kQfHXwLGsRFjlx3TCNIXlxKozRUAq4C0bxsTAWwwJWRBEfCouBVbAORsWBMB8esCLmn8JsSIPMZ0jWCNnMdVsMZcb2Qj7EPloH851wPsw+WofMt8JBDjO71IMNiphw3Q6DEawSZqHfTchCs0rouhGGE6F4yJ206qYxmpauG2E05RSlQ74MqwsxRclw54o6OEHcdRsMh6Pwtg2vy9B9EAgEAoFAIBDI5WBMaVmWlFK8jev26AymRGC+3jynLy+vaZY9b5L1Ouf1CxK0FFXC3nmggq7TeVwsT94piJbL1WpVFEU8Zi/hbj1ggVN2ZjvL1wfXDVVMiTenb4N0CW9dt1UllKbFZdxeeBMgUWz+1rcVBkfEeH4ZdiQMjEj53xewEQZFLJPL4+e5MCAiXV/l+xAGQ8T8ugp+CkMhllddg0fCMIhiei3wQBgCcf/qjqowACIZ9xN6T6Sb64HHQt+J5FdvoedErgA8FXpNpK86hD4ThcI40yL0mChUgC1Cb4lYZSRtFfpKLN+0CT0lKs0VHUI/iWoDTYfQS6JYXeYsi7fRZPL+7f1xMpmMRm8/v399u2sV+kjEl+4Mi9GP2y93Ve6r3O3y8NAB9JF4YUWzfL+/u+/SBEHEibyAN53FCoWIn6XA++vq5yORZjLhDxWgZ0SaSoDsixLQL2L5IhF+UyuhX0TyUyJsn9UDIxLJNluh2km9IsqEcR+hN0RZL+0n9IVoUOgJ0aTQD2JpUugFUXaL31/oA1E242sQekA0LXRPlO0HaxE6J8pW3nqErokWhI6JsvtDXUK3RCtCp0TZLoY+oUui7AGwRqFDomyvTafQHdGa0BnRntAV0aLQOJGStgjJK3vxP3dd8ZFIX6etkTw+XE1GHZkobjMaJZKWf8qonKWPW8Uqr3Z1Rv0KNUjUKvyuvldsjqhV2PUE2ClRq3DUQ2iMqFU46SM0RdQqVHyuaJaoVfhvL6AholZhj8du5ohahb/7Ck0QdQqX/YUGiDqFYy+3inUKf/W+Dk0QdQp7LNoMErUKe034pog6hY/9JnxDRJ3CnksaQ0Sdwj+6gFqJOoV9F21miDqFGoE3Nz4KC22Xoa/CsabJwl8h0zPheyzs+CXCgIR99qEMCukbY+NxXBSr1bW/TD+NtiWNXiEqCSEl3R4ztFgseL5ONs9Z+ip5+3JV/4DkPCONE75W4UkwxhRTShSezGgFmhM2UItP10AIQhCCEIQgBCEIQQhCEIIQhCAEIQhBCEIQghCEIAQhCEEIQhCCEIQgBCEIQQhCEIIQhCAEIQhBCEIQghCEIAQhCEEIQhCCEIQgBCEI/Rf2OoXFGyHij535T+svmp0JEb3fnhnXFhtAC0L0ZAXiUuiYaEPolmhF6JRoR+iSaEnokGhL6I5oTeiMaE/oimhR6IhoU+iGaFXogniLFgMnLhC3KrROfOIowUMmVnfgKKV2hVaJ9ZlhaFpaFlokPiFUTlEsbAutESsgEjGKrANtEXffFaEos30hWiLWFayPfUMRs99NbRC3QCRYJYxyy/OFFeIOiPOoFs6JA6Fh4v5LyHwrjLiLIhol7iqIMI92QjZzITRI3APRjO2FUeaknxojNp9PtudnboVuBhtTxKaC9TDzISzQcIgfQFQcCKNYDIX4ART7g+BQ87RyIFVsPhej5qS7RhgV+RCGm6aCJC+iU2E1os6CnxebeXB2cArxgTBinIS9gNv7CGdRu7BawOUi4DuN7YdRkc+PTMfCqo4ZEiUNcu/mCdNSoIydiE6F9bA6TRMe3Cbj7YIn6bTlqND/Ab9+rVFd+KwlAAAAAElFTkSuQmCC"
                                height="20px" width="20px" />
                        </a>
                    </div>
                    <div class="instagram">
                        <a href="instagram.png">
                            <img src="https://thumbs.dreamstime.com/b/nouvelle-ic-ne-de-logo-cam-ra-d-instagram-dans-le-vecteur-bleu-avec-les-illustrations-modernes-conception-gradient-sur-fond-blanc-144986247.jpg" height="20px" width="20px" />
                        </a>
                    </div>
                </div>
                <div class="copyright">
                    <p class="text_copyright">Copywright 2021 Etna.com</p>
                </div>
            </div>
        </footer>
    
    </body>
    
    </html>
    <style>
        header {
            font-family: 'Montserrat', sans-serif;
        }
        
        #menu_de_bord {
            width: 50%;
            margin-left: 1000px;
        }
        
        header {
            display: flex;
            justify-content: space-between;
            /* align-items: center; */
        }
        
        .account {
            display: flex;
            justify-content: space-between;
        }
        
        li>a {
            text-decoration: none;
            color: black;
        }
        
        li {
            list-style: none;
            font-weight: bold;
        }
        
        div>ul {
            display: flex;
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            align-items: center;
        }
        
        #banner {
            /* background-image: url("https://www.annuaire-web-france.fr/wp-content/uploads/assistanceinformatique76-.jpg"); */
            background-image: url("https://www.sortez.org/bannieres/accueil/data1/images/visuel3.png");
            background-size: cover;
            width: 100%;
            height: 309px;
            color: white;
            text-align: center;
            padding-top: 5%;
        }
        
        body>section>div>img {
            width: 100%;
            height: 619px;
        }
        
        body {
            margin: auto;
        }
        
        #menu_de_bord {
            width: 50%;
        }
        
        #title_banner {
            color: rgb(255, 255, 255);
            font-family: 'Poppins', sans-serif;
        }
        
        #paragraph_banner {
            font-family: 'Montserrat', sans-serif;
        }
        
        #features {
            display: flex;
            justify-content: space-around;
            padding-top: 2%;
            padding-bottom: 6%;
        }
        
        .card {
            /* Add shadows to create the "card" effect */
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            transition: 0.3s;
        }
        /* On mouse-over, add a deeper shadow */
        
        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
        }
        /* Add some padding inside the card container */
        
        .container {
            padding: 2px 16px;
        }
        
        footer {
            justify-content: center;
        }
        
        #contact_foot {
            display: flex;
            justify-content: space-evenly;
            align-items: center;
            width: 100%;
            height: 200px;
            padding-bottom: 4%;
        }
        
        .social_networks {
            display: flex;
            justify-content: space-around;
            width: 20%;
        }
        
        .copyright {
            text-align: center;
            width: 20%;
        }
        
        .logo2 {
            width: 20%;
        }
    </style>
        
    </div>
</body>
</html>
