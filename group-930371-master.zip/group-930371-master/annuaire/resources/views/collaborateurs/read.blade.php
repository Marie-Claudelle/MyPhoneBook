<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../collaborateur.css" type="text/css" media="screen" />
        <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

        <title>Document</title>
    </head>
        <body>
        <table action="{{ route('collarateur.store') }}" method="GET" class="my_table">
            <div>
                <div class="title">Liste des Collaborateurs</div>
                <div class="subtitle">Veulliez remplir tous les champs!</div>
            </div>
            <thead>
                <tr>
                    <th>Civilité</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Rue </th>
                    <th>CP</th>
                    <th>Ville</th>
                    <th>Téléphone</th>
                    <th>Email</th>
                    <th>Action</th>

                </tr>
            </thead>
            {{#each listCollaborateurs  }}
            <tbody>  
                <tr>
                    <td>{{$collaborateur -> civilite }} </td>
                    <td>{{ }}</td>
                    <td>{{ }}</td>
                    <td>{{ }}</td>
                    <td>{{ }}</td>
                    <td>{{ }}</td>
                    <td>{{ }}</td>
                    <td>{{ }}</td>
                    <td>
                        <div>
                            <i class='fas fa-pen'></i> 
                        </div>
                        <div>
                            <i class='fas fa-trash-alt'></i>
                        </div>
                    </td>
                </tr>
            {{/each }}
            </tbody>
        </table>


        </body>
</html>