<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>My Phone Book</title>
   <link rel="stylesheet" type="text/css"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <script type="text/javascript" src="connexion.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>


<script>
  $( function() {
    $( "#tabs" ).tabs();
  } );
  </script>

</head>

<body>





    <div class="text">
        <h1 style="color: coral;padding-left: 525px; align: center;">Modifier un collaborateur</h1>
    </div>



    <div id="tabs">
        

        <div id="tabs-1">
            <!--creer une entreprise-->
            <form action="{{ route('collaborateur.update', $collaborateur->id) }}" method="POST">
            @csrf
            @method('PUT')
                <div style="margin: auto;width: 60%; margin-left: 30%;">

                   <div style="display: inline-block; padding-right: 20%; padding-top: 10%"> <label><strong>Civilité: </strong></label></br>

                        Homme: <input type="radio" name="genre" value="male" @if( $collaborateur->civilite == "male") checked @endif />
                        Femme: <input type="radio" name="genre" value="female" @if( $collaborateur->civilite == "female") checked @endif />
                        Non-binaire: <input type="radio" name="genre" value="autre" @if( $collaborateur->civilite == "autre") checked @endif/></br>
                    </div></br>

                    <div class="let" style="display: inline-block; padding-right: 20%; padding-top: 10%;"><label
                        for="nom"><strong>Nom*</strong></label><br />
                        <input type="text" name="nom" value="{{ $collaborateur->nom }}" required="" style="height: 45px;" />
                    </div>

                    <div class="let" style="display: inline-block;"><label
                            for="prenoms"><strong>Prénom*</strong></label><br />
                        <input type="text" name="prenom" value="{{ $collaborateur->prenom }}" required="" style="height: 45px;" />
                    </div>


                    <div style="display: inline-block; padding-right: 20%; padding-top: 10%;"><label for="domaine"><strong>Ville*</strong></label><br />
                        <input type="text" name="ville" value="{{ $collaborateur->ville }}" required="" style="height: 45px;" />
                    </div>

                    <div class="let" style="display: inline-block;"><label
                            for="localité"><strong> Rue*</strong></label><br />
                        <input type="localité" name="rue" value="{{ $collaborateur->rue }}" required="" style="height: 45px;" />
                    </div>

                    <div class="let" style="display: inline-block;  padding-right: 20%; padding-top: 10%;"><label for="nombre1"><strong>Code Postal* </strong></label><br />
                        <input type="nombre" name="code_postal" value="{{ $collaborateur->code_postal }}" style="height: 45px;" placeholder="1xxxx" required=""/>
                    </div>

                    <div class="let" style="display: inline-block; "><label for="numero_de_telephone"><strong>Numéro de téléphone*</strong></label><br />
                        <input type="tel" name="numero_de_telephone" value="{{ $collaborateur->numero_de_telephone }}" placeholder="01xxxxxxxx" pattern="01[0-9]{8}" required="" style="height: 45px;" />
                    </div>

                    <div class="let" style="display: inline-block;  padding-right: 20%; padding-top: 10%;"><label for="email"><strong>Email* </strong> </label><br>
                        <input value="{{ $collaborateur->email }}" type="email" placeholder="prenom.nom@gmail.com" name="email" required="" style="height: 45px"><br>
                    </div>

                    <div class="let" style="display: inline-block; padding-right: 20%; padding-top: 10%;">
                        <label for="nom_entreprise"><strong>Nom de votre entreprise*</strong></label><br />
                        <select name="nom_entreprise" id="entreprise_id" required="" style="height: 45px;">
                            @foreach ($ids as $nom=>$id)
                            <option value="{{$id}}" @if($id == $collaborateur->entreprise_id) selected="selected"@endif> {{$nom}}</option>
                                
                            @endforeach
                        </select>
                    </div>
                    
                    <div><input type="submit" value="Modifier" style="margin-left: 700px;" /></div>

                </div>  

                
            </form>

        </div>
        @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
                        </ul>
                    </div>
            @endif


    <!--script-->
    <script rel="stylesheet" type="text/css"
        src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    </script>
    <script type="text/javascript" src="connexion.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    

</body>

</html>